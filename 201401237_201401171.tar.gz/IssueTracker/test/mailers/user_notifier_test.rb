require 'test_helper'

class UserNotifierTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
